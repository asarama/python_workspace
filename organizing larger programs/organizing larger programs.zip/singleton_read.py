import singleton

def read_singleton_state():
    for item in singleton.list_values():
        print(item)