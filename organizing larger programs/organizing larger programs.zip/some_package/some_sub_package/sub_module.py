class SomeSubClass:

    def __init__(self):
        print("sub something init")


    def print(self, text):
        print(f"sub something printing: {text}")