class SomeClass:

    def __init__(self):
        print("something init")


    def print(self, text):
        print(f"something printing: {text}")