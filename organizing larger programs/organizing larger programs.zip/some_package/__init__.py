# relative imports
from .some_module import SomeClass
from .some_sub_package.sub_module import SomeSubClass

# absolute imports
# from some_package.some_module import SomeClass