_list = []

def add_to_list(value):
    _list.append(value)

def list_values():
    return iter(_list)